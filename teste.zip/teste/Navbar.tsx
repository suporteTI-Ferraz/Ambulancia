'use client';

// src/components/Navbar.tsx
import React, { useState } from 'react';
import './Navbar.css'; // Importa o arquivo CSS para a navbar

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="header">
      <a className="logo" href="#home"><span>m</span>ussie</a>
      <div className="menu" onClick={toggleMenu}>
        <i className="fa fa-bars" aria-hidden="true"></i>
      </div>
      <nav className={`navbar ${isMenuOpen ? 'active' : ''}`}>
        <ul>
          <li><a href="#home">home</a></li>
          <li><a href="#novidades">novidades</a></li>
          <li><a href="#sobre">sobre</a></li>
          <li><a href="#">cadastro</a></li>
          <li><a href="#">login</a></li>
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;
