// src/pages/index.tsx
import React from 'react';
import Navbar from './components/Navbar';
import './globals.css';

const Page: React.FC = () => {
  return (
    <div>
      <Navbar />
      {/* Outras seções do seu site */}
    </div>
  );
};

export default Page;
